
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Currency Calculator</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    
    <?php


    
    $kurlar = simplexml_load_file("https://www.tcmb.gov.tr/kurlar/today.xml");
    $froma=$result=$x="0";

    $USDCAD_CROSS=$kurlar->Currency[7]->CrossRateUSD;
    $EURUSD_CROSS=$kurlar->Currency[3]->CrossRateOther;

    $currencys=array("USDCAD"=>$USDCAD_CROSS, "CADUSD"=>(1/$USDCAD_CROSS), "USDEUR"=>(1/$EURUSD_CROSS), "EURUSD"=>$EURUSD_CROSS, "CADEUR"=>(1/$EURUSD_CROSS/$USDCAD_CROSS), "EURCAD"=>($EURUSD_CROSS*$USDCAD_CROSS), "USDUSD"=>1, "EUREUR"=>1, "CADCAD"=>1,);
    $banknots=array("USD"=>"USD Dollars", "EUR"=>"Euro", "CAD"=>"Canadian Dollars");

    if($_SERVER["REQUEST_METHOD"]=="POST"){
       
       $x=$_POST["froma"];
       $froma=$_POST["fromCurrency"];
       $toa=$_POST["toCurrency"];
       $change=$_POST["fromCurrency"].$_POST["toCurrency"];
       $result= ($currencys["$change"]*$x);
       $banknot1=($banknots["$froma"]);
       $banknot2=($banknots["$toa"]);
        


    }



?>
</head>
<body>
<form action="" method="post">
<div class="from">
    <div class="lbl"><label>From</label></div>
    <div class="first"><input type="text"  class="input" name="froma" value="<?php echo @$x; ?>"></div required>
    </div>
    <div class="first"><label>Currency</label></div>
    <div class="first"><select name="fromCurrency" class="select" >
        

    <?php
            if(empty(@$x)==false){
                echo "<option value='$froma'>$banknot1</option>";
            }
        foreach(@$banknots as $key=> $val){

            
            echo "<option value='$key'>$val</option>";
            
        }


        ?>

        </select>
        </div>

</div>


<div class="currency">
<div>
    <div class="lbl"><label>To</label></div>
    <div class="second"><input type="text" class="input" name="toa" value="<?php echo @$result;?>"></div>
    </div>

        <div class="second"><label>Currency</label></div>
    <div class="second"><select name="toCurrency" class="select">
    
    <?php
            if(empty(@$x)==false){
                echo "<option value='$toa'>$banknot2</option>";
            }
        foreach(@$banknots as $key=> $val){

            
            echo "<option value='$key'>$val</option>";
            
        }
            
        ?>
        </select>
        </div>

</div>


<div class="sbmt"><input type="submit" value="Convert"></div>  


</form>


</body>
</html>