<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registeration Preview</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h1>Preview</h1>
    <div>
    <?php
        if($_SERVER["REQUEST_METHOD"]=="POST"){
            $name=$username=$password=$address=$country=$zip=$email=$sex=$language=$about="";
            $name=bosmu($_POST["name"]);
            $username=bosmu($_POST["username"]);
            $password=bosmu($_POST["password"]);
            $address=bosmu($_POST["address"]);
            $country=bosmu($_POST["country"]);
            $zip=bosmu($_POST["zip"]);
            $email=bosmu($_POST["email"]);
            $sex=bosmu($_POST["sex"]);
            $language=$_POST["language"];
            $language2=$_POST["language2"];
            $language3=$_POST["language3"];
            $about=bosmu($_POST["about"]);

            echo $name."<br>";
            echo $username."<br>";
            echo $password."<br>";
            echo $address."<br>";
            echo $country."<br>";
            echo $zip."<br>";
            echo $email."<br>";
            echo $sex."<br>";
            echo $language."<br>".$language2."<br>".$language3."<br>";

            echo $about."<br>";



        }
        function bosmu($text){
         if (empty($text)) {
                  $text="Not provided";
              
                } 
                
              return $text;
          }


        ?>


    </div>
</body>
</html>