<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registeration Form</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h1>Registeration Form</h2>
    <form action="Activity4-preview.php" method="post">
    <div>
    <div class="lbl"><label>Name</label></div>
    <div class="inpt"><input type="text" class="input" name="name"></div>
    </div>

    <div>
    <div class="lbl"><label>Username</label></div>
    <div class="inpt"><input type="text" class="input" name="username"></div>
    </div>
    
    <div>
    <div class="lbl"><label>Password</label></div>
    <div class="inpt"><input type="text" class="input" name="password"></div>
    </div>

    <div>
        <div class="lbl">
        <label>Address</label></div>
        <div class="inpt">
        <input type="text" class="input" name="address">
        </div>
    </div>

    <div>
    <div class="lbl"><label>Country</label></div>
    <div class="inpt"><select name="country" class="select">
        
        <option value="Not provided">Select an option</option>
        <option value="ABD">ABD</option>
        <option value="TR">Turkiye</option>
        <option value="UK">Unitet Kingdom</option>

        </select>
        </div>

    </div>

    <div>
    <div class="lbl"><label>ZIP Code</label></div>
    <div class="inpt"><input type="text" class="input" name="zip"></div>
    </div>

    <div>
    <div class="lbl"><label>Email</label></div>
    <div class="inpt"><input type="email" class="input" name="email"></div>
    </div>

    <div>
    <div class="lbl"><label>Sex</label></div>
    <div class="inpt"><input type="radio" class="input" name="sex" value="Male">
        <label value="male">Male</label>
        <input type="radio" class="input" name="sex" value="Female">
        <label value="female">Female</label></div>

    </div>

    <div>
    <div class="lbl"><label>Language</label></div>
    <div class="inpt"><input type="checkbox" class="input" name="language" value="English">
        <label for="language">English</label>
        <input type="checkbox" class="input" name="language2" value="French">
        <label for="language">French</label>
        <input type="checkbox" class="input" name="language3" value="German">
        <label for="language">Germany</label></div>





    </div>

    <div>
    <div class="lbl"><label>About</label></div>
    <div class="inpt"><textarea class="input" name="about" rows="5"></textarea></div>
    </div>
    <div class="sbmt">
    <input type="submit" value="Submit">
    </div>   
        
</form>
    
</body>
</html>